package com.example.diceroller

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import java.util.*

// every thing you do you add an id and link the id to a variable that we name to the button
// or whatever instance you want to link it to thats part of the layoiut
// then we reate a fucntion that does what we want once th eitem is pressd
// then we link th efunction to the setOnClicklistener
class MainActivity : AppCompatActivity() {
    lateinit var diceImage : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        diceImage = findViewById(R.id.dice_image)

        val rollButton: Button = findViewById(R.id.roll_button);
        rollButton.setOnClickListener { rollDice() }

       // val upOne: Button = findViewById(R.id.up)
       // upOne.setOnClickListener { up()}
    }

    private fun rollDice(){
       // Toast.makeText(this,"button clicked", Toast.LENGTH_SHORT).show()

        val diceImage : ImageView = findViewById(R.id.dice_image)
        val randomInt = Random().nextInt(6)+1

        val drawableResouce = when (randomInt){
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            6 -> R.drawable.dice_6
            else -> R.drawable.dice_6
        }

        diceImage.setImageResource(drawableResouce)

        //Toast.makeText(this,randomInt.toString(),Toast.LENGTH_SHORT).show()
    }


//    private fun up(){
  //  val resultUp : TextView = findViewById(R.id.result_text)
    //    val num = resultUp.text.toString()

      //  if(num.equals("Hello World!") ){
        //    resultUp.text = "1"
        //}
        //else if(num.toInt()<6) {
          //  val upOne = num.toInt() + 1
           // resultUp.text = upOne.toString()
       // }




    }





